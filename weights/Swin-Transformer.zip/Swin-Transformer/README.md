# Swin-Transformer
Image classification Using Swin Transformer.

Check this video for better understanding: https://www.youtube.com/watch?v=OX089A-p_Cg 

![a](https://github.com/AarohiSingla/Swin-Transformer/assets/60029146/99790400-bd0d-4706-af67-8b57082b8e22)


![Swin_tranformer_entire_exp](https://github.com/AarohiSingla/Swin-Transformer/assets/60029146/cbd74a60-2506-4cfc-b778-3326ed5873dd)
