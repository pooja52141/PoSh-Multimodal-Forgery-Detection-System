# GENERATED VERSION FILE
# TIME: Tue Apr 16 14:13:58 2024
__version__ = '0.3.0'
__gitsha__ = 'a4abfb2'
version_info = (0, 3, 0)
